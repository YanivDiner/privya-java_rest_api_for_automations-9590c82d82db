#!/bin/bash
cd /opt/tomcat8/bin
./startup.sh
