package main.java.controllers;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @PostMapping("/users")
    public String createUser(@RequestBody User user_name) {
        // Logic to create the user in the database
        // This method will be triggered when a POST request is made to "/users"
        
        return "User created successfully: " + user.getUsername();
    }
}
