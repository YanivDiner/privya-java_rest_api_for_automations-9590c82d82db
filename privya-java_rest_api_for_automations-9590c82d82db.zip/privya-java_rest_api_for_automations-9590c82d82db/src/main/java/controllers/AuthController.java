import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}

@RestController
@RequestMapping("/api")
public class TestController {

    // Authentication logic (placeholder)
    private boolean isUserAuthenticated() {
        // Implement your authentication logic here
        return true;
    }
    @login
    @GetMapping("/protected_route/{id}")
    public String protectedRoute(@PathVariable String id) {
        if (isUserAuthenticated()) {
            return "Hello, " + id + "! This is a protected route.";
        } else {
            return "Authentication failed. This is a protected route.";
        }
    }
    @login
    @GetMapping("/protected_route_2/{email}")
    public String protectedRoute2(@PathVariable String email) {
        if (isUserAuthenticated()) {
            // You can replace "user.username" with the actual username
            String username = "JohnDoe"; // Replace with your logic to get the username
            return "Hello, " + username + "! This is a protected route.";
        } else {
            return "Authentication failed. This is a protected route.";
        }
    }

    @GetMapping("/not_protected_route")
    public String notProtectedRoute() {
        return "This is not a protected route.";
    }
}