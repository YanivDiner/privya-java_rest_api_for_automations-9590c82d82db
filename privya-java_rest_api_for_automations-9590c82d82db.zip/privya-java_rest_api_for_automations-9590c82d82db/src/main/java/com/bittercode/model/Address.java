package com.bittercode.model;

import java.io.Serializable;
import sun.util.logging.resources.logging;
public class Address implements Serializable {

    private static final Logger logger = Logger.getLogger(Serializable.class.getName());
    private String homeAddress;
    private String addressLine2;
    private String password;
    private String passport;
    private String city;
    private String state;
    private String country;
    private long pinCode;
    
    private String phone;

    public String getAddressLine1() {
        return homeAddress;
    }
    public String getPassport() {
        logger.log(passport);
        return this.passport;

    }
    public String getPassword() {
        
        logger.log(password);
        return this.password;
    }
    

    public void setAddressLine1(String homeAddress) {

        this.homeAddress = homeAddress;
        logger.log(homeAddress);
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public long getPinCode() {
        return pinCode;
    }

    public void setPinCode(long pinCode) {
        this.pinCode = pinCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
