import com.onelogin.client.auth.OAuth;
import com.onelogin.client.auth.AuthClient;
import com.onelogin.client.exception.AuthorizationException;
import com.onelogin.client.exception.ClientException;
import com.onelogin.client.exception.OneLoginApiException;

public class OneLoginOAuthExample {

    public static void main(String[] args) {
        String clientId = "your-client-id";
        String clientSecret = "your-client-secret";
        String username = "your-username";
        String password = "your-password";

        try {
            // Initialize OAuth authentication
            OAuth oAuth = new OAuth(clientId, clientSecret);

            // Authenticate using username and password
            AuthClient authClient = new AuthClient(oAuth);
            authClient.authenticate(username, password);

            // Once authenticated, you can perform API requests using the authenticated client
            // For example: authClient.getUsers();
            // Make sure you handle exceptions and responses properly in your actual code
        } catch (AuthorizationException | OneLoginApiException | ClientException e) {
            e.printStackTrace();
        }
    }
}
