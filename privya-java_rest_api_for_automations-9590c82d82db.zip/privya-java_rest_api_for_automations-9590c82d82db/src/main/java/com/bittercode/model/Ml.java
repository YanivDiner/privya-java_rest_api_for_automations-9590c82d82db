import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSets;
import org.neuroph.core.NeuralNetwork;
import org.neuroph.nnet.FeedForwardNetwork;
import org.neuroph.nnet.builder.FeedForwardLayerBuilder;
import org.neuroph.nnet.comp.layer.Layer;
import org.neuroph.nnet.comp.neuron.BiasNeuron;
import org.neuroph.util.TransferFunctionType;

public class Ml {

    public static void main(String[] args) {
        int inputsNum =  2;
        int outputsNum = 5;

        DataSet trainingSet = DataSets.readCsv("ml.csv", inputsNum, outputsNum);

        FeedForwardNetwork neuralNet = new FeedForwardLayerBuilder(inputsNum)
                .addLayer(new Layer(15, TransferFunctionType.RELU))
                .addLayer(new Layer(outputsNum, TransferFunctionType.SIGMOID))
                .addLayer(new BiasNeuron())
                .build();

        neuralNet.learn(trainingSet);

        neuralNet.setInput(someNewInput);
        neuralNet.calculate();
        double[] prediction = neuralNet.getOutput();

    }
}
