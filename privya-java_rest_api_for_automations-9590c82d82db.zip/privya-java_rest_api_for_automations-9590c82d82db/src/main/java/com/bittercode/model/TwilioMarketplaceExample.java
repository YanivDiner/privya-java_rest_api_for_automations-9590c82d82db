import com.twilio.Twilio;
import com.twilio.rest.preview.marketplace.AvailableAddOn;
import com.twilio.rest.preview.marketplace.AvailableAddOnFetcher;
import com.twilio.rest.preview.marketplace.InstalledAddOn;
import com.twilio.rest.preview.marketplace.InstalledAddOnFetcher;
import com.twilio.rest.preview.marketplace.InstalledAddOnReader;
import com.twilio.rest.preview.marketplace.InstalledAddOnCreator;

public class TwilioMarketplaceExample {

    public static final String ACCOUNT_SID = "your-account-sid";
    public static final String AUTH_TOKEN = "your-auth-token";

    public static void main(String[] args) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        // Fetch available add-ons
        AvailableAddOnFetcher fetcher = AvailableAddOn.fetcher();
        ResourceSet<AvailableAddOn> availableAddOns = fetcher.read();

        System.out.println("Available Add-Ons in the Twilio Marketplace:");
        for (AvailableAddOn addOn : availableAddOns) {
            System.out.println("SID: " + addOn.getSid());
            System.out.println("Friendly Name: " + addOn.getFriendlyName());
            System.out.println("Description: " + addOn.getDescription());
            System.out.println("Categories: " + addOn.getCategories());
            System.out.println("=====================================");
        }
    }
}
 {
    
}
