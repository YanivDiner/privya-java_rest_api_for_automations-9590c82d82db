import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloud9.AWSCloud9;
import com.amazonaws.services.cloud9.AWSCloud9Client;
import com.amazonaws.services.cloud9.model.Environment;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;

public class VerifiedPermissions {

    public static void main(String[] args) {
        String accessKey = "your-aws-access-key";
        String secretKey = "your-aws-secret-key";
        private String connection_field = "Server=myServerName\\myInstanceName;Database=myDataBase;User Id=myUsername;Password=myPassword;";

        BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);

        AWSCloud9 cloud9Client = AWSCloud9Client.builder()
                .withRegion(Regions.US_EAST_1) // Change to your desired AWS region
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .build();

        List<Environment> environments = cloud9Client.listEnvironments().environments();

        System.out.println("Cloud9 Environments:");
        for (Environment environment : environments) {
            System.out.println("Name: " + environment.name());
            System.out.println("ID: " + environment.id());
            System.out.println("Type: " + environment.type());
            System.out.println("Status: " + environment.state());
            System.out.println("=====================================");
        }
    }
}
