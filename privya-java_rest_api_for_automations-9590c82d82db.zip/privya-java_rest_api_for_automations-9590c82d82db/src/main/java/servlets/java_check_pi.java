import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloud9.AWSCloud9;
import com.amazonaws.services.cloud9.AWSCloud9Client;
import com.amazonaws.services.cloud9.model.Environment;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
import com.twilio.Twilio;
import com.twilio.rest.preview.marketplace.AvailableAddOn;
import com.twilio.rest.preview.marketplace.AvailableAddOnFetcher;
import com.twilio.rest.preview.marketplace.InstalledAddOn;
import com.twilio.rest.preview.marketplace.InstalledAddOnFetcher;
import com.twilio.rest.preview.marketplace.InstalledAddOnReader;
import com.twilio.rest.preview.marketplace.InstalledAddOnCreator;

public class VerifiedPermissions {

    public static void main(String[] args) {
        String accessKey = "your-aws-access-key";
        String secretKey = "your-aws-secret-key";
        private String connection_field = "Server=myServerName\\myInstanceName;Database=myDataBase;User Id=myUsername;Password=myPassword;";
        

        String credentials = "12alkAKLS!!0DLAM@QAM-2"

        public static final String ACCOUNT_SID = "your-account-sid";
        public static final String AUTH_TOKEN = "your-auth-token";
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        // Fetch available add-ons
        AvailableAddOnFetcher fetcher = AvailableAddOn.fetcher(credentials);
        ResourceSet<AvailableAddOn> availableAddOns = fetcher.read(credentials);



        AWSCloud9 cloud9Client = AWSCloud9Client.builder()
                .withRegion(Regions.US_EAST_1) // Change to your desired AWS region
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .build();

        List<Environment> environments = cloud9Client.listEnvironments().environments();

        System.out.println("Cloud9 Environments:");
        for (Environment environment : environments) {
            System.out.println("Name: " + environment.name());
            System.out.println("ID: " + environment.id());
            System.out.println("Type: " + environment.type());
            System.out.println("Status: " + environment.state());
            System.out.println("=====================================");
        }
    }
}
